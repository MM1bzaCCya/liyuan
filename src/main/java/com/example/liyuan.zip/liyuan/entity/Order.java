package com.example.liyuan.entity;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class Order {
    private Long id;
    private Long requestId;
    private Long grabId;
    private Long userId;
    private Long singerId;
    private String songName;
    private String originalSinger;
    private Integer status; // 0-待演唱, 1-演唱中, 2-已完成, 3-已取消
    private Integer queueNumber;
    private LocalDateTime singTime;
    private LocalDateTime completeTime;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;

    // 关联字段（非数据库字段）
    private String requesterName;
    private String requesterAvatar;
    private String singerName;
    private String singerAvatar;
}